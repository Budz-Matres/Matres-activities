require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const userRoutes = require('./routes/user');
const { limiter, requestLogger } = require('./middleware/authMiddleware');
const app = express();
const PORT = process.env.PORT || 3000;

const tokenSecret = process.env.TOKEN_SECRET;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

app.use(requestLogger);

app.use(limiter);

app.use('/api/users', userRoutes); 

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});
