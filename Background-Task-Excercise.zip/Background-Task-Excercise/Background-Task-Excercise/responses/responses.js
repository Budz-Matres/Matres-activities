const genericError = (res, error) => {
	status = 500;
	message = 'Internal Server Error';
	if (error) {
		message = error.message;
	}
	res.status(
		status
	).json({
		status: status,
		message: message
	});
}

module.exports = {
	genericError
}