const authMiddleware = (req, res, next) => {
    const token = req.headers.authorization;
  
    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }
  
    const userId = parseInt(token.split('_')[2]);
    if (isNaN(userId)) {
      return res.status(401).json({ message: 'Invalid token' });
    }
  
    req.userId = userId;
    next();
  };
  
  const loggingMiddleware = (req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
  };
  
  module.exports = {
    authMiddleware,
    loggingMiddleware
  };